package s.mironov.MyFirstAppSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstAppSpringBootApplication.class, args);
	}

}
