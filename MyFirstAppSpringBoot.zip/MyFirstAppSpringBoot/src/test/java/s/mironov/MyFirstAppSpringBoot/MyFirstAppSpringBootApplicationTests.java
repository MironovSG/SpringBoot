package s.mironov.MyFirstAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
