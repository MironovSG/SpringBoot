package ru.mironov.MyTestRest2DBApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTestRest2DbAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTestRest2DbAppApplication.class, args);
	}

}
