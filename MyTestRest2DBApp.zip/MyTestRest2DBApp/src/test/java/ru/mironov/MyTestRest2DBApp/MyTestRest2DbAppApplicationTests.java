package ru.mironov.MyTestRest2DBApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTestRest2DbAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
