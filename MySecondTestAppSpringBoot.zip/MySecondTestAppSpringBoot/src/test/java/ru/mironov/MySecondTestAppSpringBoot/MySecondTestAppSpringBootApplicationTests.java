package ru.mironov.MySecondTestAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySecondTestAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
